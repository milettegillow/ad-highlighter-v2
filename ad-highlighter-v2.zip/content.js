// ============================================================
// Ad Highlighter v2 — Content Script
// Two-layer detection: site-specific rules + generic island analysis
// ============================================================

(function () {
  "use strict";

  if (window.__adHighlighterV2Loaded) return;
  window.__adHighlighterV2Loaded = true;

  // ----------------------------------------------------------
  // 1. CONFIGURATION
  // ----------------------------------------------------------

  // CSS class/id patterns for ad containers (used by findAdContainer & island scoring)
  const AD_CLASS_PATTERNS = [
    "ad-container",
    "ad-wrapper",
    "ad-slot",
    "ad-unit",
    "ad-banner",
    "ad-block",
    "ad-placement",
    "ad-holder",
    "adsbygoogle",
    "sponsored-post",
    "sponsored-content",
    "sponsored-card",
    "promoted-post",
    "promoted-content",
    "promoted-card",
    "advertisement",
    "dfp-ad",
    "gpt-ad",
    "native-ad",
    "in-feed-ad",
    "outbrain",
    "taboola",
    "revcontent",
    "mgid",
  ];

  // Known ad-serving iframe domains
  const AD_IFRAME_DOMAINS = [
    "doubleclick.net",
    "googlesyndication.com",
    "googleadservices.com",
    "amazon-adsystem.com",
    "adnxs.com",
    "criteo.com",
    "outbrain.com",
    "taboola.com",
    "revcontent.com",
    "mgid.com",
    "adsrvr.org",
    "rubiconproject.com",
    "pubmatic.com",
    "openx.net",
    "casalemedia.com",
    "media.net",
  ];

  // Soft-signal keywords (only for scoring in fallback, never standalone detection)
  const SOFT_KEYWORDS = [
    "sponsored",
    "promoted",
    "advertisement",
    "advertorial",
    "ad disclosure",
    "paid partnership",
  ];

  const EXCLUDED_TAGS = new Set([
    "HTML",
    "BODY",
    "HEAD",
    "MAIN",
    "NAV",
    "HEADER",
    "FOOTER",
    "SCRIPT",
    "STYLE",
    "NOSCRIPT",
    "META",
    "LINK",
    "TITLE",
  ]);

  const CONTAINER_TAGS = new Set([
    "ARTICLE",
    "SECTION",
    "LI",
    "DIV",
    "ASIDE",
    "FIGURE",
    "BLOCKQUOTE",
    "TD",
    "TR",
  ]);

  // ----------------------------------------------------------
  // 2. STATE
  // ----------------------------------------------------------

  let enabled = true;
  let highlightedElements = new Map();
  let dismissedSelectors = new Set();
  const domain = window.location.hostname;

  function isContextValid() {
    try { return !!chrome.runtime?.id; } catch (e) { return false; }
  }

  chrome.storage.local.get(["enabled", `dismissed_${domain}`], (result) => {
    if (result.enabled === false) {
      enabled = false;
    } else {
      enabled = true;
      scanPage();
    }
    if (result[`dismissed_${domain}`]) {
      dismissedSelectors = new Set(result[`dismissed_${domain}`]);
    }
  });

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "toggle") {
      enabled = msg.enabled;
      if (enabled) {
        scanPage();
      } else {
        clearAllHighlights();
      }
      sendResponse({ ok: true });
    }
    if (msg.type === "getStats") {
      sendResponse({ count: highlightedElements.size, enabled });
    }
    if (msg.type === "rescan") {
      clearAllHighlights();
      if (enabled) scanPage();
      sendResponse({ ok: true });
    }
  });

  // ----------------------------------------------------------
  // 3. DETECTION ENGINE
  // ----------------------------------------------------------

  function scanPage() {
    if (!enabled || !isContextValid()) return;
    const found = new Set();

    // Layer 1: Site-specific detection for known sites
    const siteDetector = getSiteDetector();
    if (siteDetector) {
      console.log("[AdHighlighter] Using site-specific detector for:", domain);
      siteDetector(found);
    } else {
      // Layer 2: Generic fallback for unknown sites only
      console.log(
        "[AdHighlighter] No site rules, using generic detection for:",
        domain,
      );
      detectAdIframes(found);
      detectByIslandAnalysis(found);
    }

    // Deduplicate: if element A contains element B, keep only the outermost A
    const unique = [...found].filter((el) => {
      return ![...found].some((other) => other !== el && other.contains(el));
    });

    console.log("[AdHighlighter] Scan complete. Elements found:", found.size, "unique:", unique.length);

    unique.forEach((el) => {
      if (!highlightedElements.has(el) && !isDismissed(el)) {
        highlightElement(el);
      }
    });

    updateBadge();
  }

  function getSiteDetector() {
    if (/(?:^|\.)google\.\w+(\.\w+)?$/.test(domain)) return detectGoogleAds;
    if (/(?:^|\.)youtube\.com$/.test(domain)) return detectYouTubeAds;
    if (/(?:^|\.)facebook\.com$/.test(domain)) return detectFacebookAds;
    if (/(?:^|\.)instagram\.com$/.test(domain)) return detectInstagramAds;
    if (/(?:^|\.)amazon\.\w+(\.\w+)?$/.test(domain)) return detectAmazonAds;
    if (/(?:^|\.)linkedin\.com$/.test(domain)) return detectLinkedInAds;
    if (
      /(?:^|\.)twitter\.com$/.test(domain) ||
      /(?:^|\.)x\.com$/.test(domain)
    )
      return detectTwitterAds;
    if (/(?:^|\.)reddit\.com$/.test(domain)) return detectRedditAds;
    if (/(?:^|\.)booking\.com$/.test(domain)) return detectBookingAds;
    return null;
  }

  // ---- Site-specific detectors ----

  function detectGoogleAds(found) {
    // Skip empty ad placeholders: must be tall enough and have text content
    function isRealAdBlock(el) {
      if (el.getBoundingClientRect().height < 100) return false;
      if (el.textContent.trim().length < 20) return false;
      return true;
    }

    // 1. Traditional wrapper IDs — highlight directly (these contain ad blocks)
    for (const id of ["tads", "bottomads"]) {
      const container = document.getElementById(id);
      if (container && isRealAdBlock(container)) {
        console.log("[AdHighlighter] Google: found #" + id, {
          childCount: container.children.length,
        });
        found.add(container);
      }
    }

    // 2. Elements with data-text-ad attribute — highlight the element DIRECTLY
    //    (do NOT use findAdContainer which walks to wrong parent)
    document.querySelectorAll("[data-text-ad]").forEach((el) => {
      if (!found.has(el) && isRealAdBlock(el)) {
        console.log("[AdHighlighter] Google: found [data-text-ad]", {
          tag: el.tagName,
          class: el.className,
          id: el.id,
        });
        found.add(el);
      }
    });

    // 3. "Sponsored" / "Sponsored result(s)" heading text
    //    Walk up to find the parent section that contains the heading AND the
    //    ad listings below it. Do NOT use findAdContainer.
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      null,
    );
    let node;
    while ((node = walker.nextNode())) {
      const text = node.textContent.trim().toLowerCase();
      if (
        text === "sponsored" ||
        text === "sponsored result" ||
        text === "sponsored results"
      ) {
        const parentEl = node.parentElement;
        if (!parentEl) continue;

        console.log(
          "[AdHighlighter] Google: found '" + text + "' text node in <" + parentEl.tagName.toLowerCase() + ">",
          {
            class: parentEl.className,
            parentTag: parentEl.parentElement?.tagName,
            parentClass: parentEl.parentElement?.className,
          },
        );

        // First check if already inside a data-text-ad or #tads/#bottomads
        const existingAd = walkUpTo(parentEl, (ancestor) => {
          if (ancestor.getAttribute("data-text-ad") !== null) return true;
          if (ancestor.id === "tads" || ancestor.id === "bottomads") return true;
          return false;
        });
        if (existingAd) {
          console.log("[AdHighlighter] Google: Sponsored text already inside known ad container, skipping");
          continue;
        }

        // Walk up to find a section that contains both the heading and
        // ad result listings (multiple child divs with links)
        const section = walkUpTo(
          parentEl,
          (ancestor) => {
            // Look for a container with the heading + multiple ad-like children
            if (ancestor.children.length < 2) return false;
            // Check if it has data-text-ad descendants (the actual ads)
            const adDescendants = ancestor.querySelectorAll("[data-text-ad]");
            if (adDescendants.length > 0) return true;
            // Or check if it has multiple child divs with links (ad cards)
            let childrenWithLinks = 0;
            for (const child of ancestor.children) {
              if (child.querySelector("a[href]")) childrenWithLinks++;
            }
            return childrenWithLinks >= 2;
          },
          10,
        );

        if (section && isRealAdBlock(section)) {
          console.log("[AdHighlighter] Google: flagging Sponsored section", {
            tag: section.tagName,
            class: section.className,
            id: section.id,
            childCount: section.children.length,
          });
          found.add(section);
        } else {
          console.log(
            "[AdHighlighter] Google: Sponsored text found but no suitable section, skipping",
          );
        }
      }
    }
  }

  // ---- YouTube: overlay approach ----
  // YouTube's stacking contexts hide CSS-based highlights behind thumbnails.
  // We create position:absolute overlays on document.body instead.
  const ytOverlaid = new WeakSet();

  function ytCreateOverlay(el) {
    if (ytOverlaid.has(el)) return;
    ytOverlaid.add(el);

    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    const overlay = document.createElement("div");
    overlay.className = "adh-v2-yt-overlay";
    overlay.style.cssText = [
      "position: absolute",
      "top: " + Math.round(rect.top + window.scrollY) + "px",
      "left: " + Math.round(rect.left + window.scrollX) + "px",
      "width: " + Math.round(rect.width) + "px",
      "height: " + Math.round(rect.height) + "px",
      "border: 4px solid #ff2d2d",
      "background: rgba(255, 45, 45, 0.1)",
      "pointer-events: none",
      "z-index: 2147483647",
      "border-radius: 8px",
      "box-sizing: border-box",
    ].join(" !important;") + " !important";

    const badge = document.createElement("div");
    badge.textContent = "\u26A0 AD DETECTED";
    badge.style.cssText = [
      "position: absolute",
      "bottom: -28px",
      "left: 0",
      "background: #ff2d2d",
      "color: white",
      "font-size: 12px",
      "font-weight: 700",
      "padding: 4px 10px",
      "border-radius: 4px",
      "pointer-events: none",
      "font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      "letter-spacing: 0.3px",
      "line-height: 16px",
    ].join(" !important;") + " !important";
    overlay.appendChild(badge);

    document.body.appendChild(overlay);
    highlightedElements.set(overlay, { btn: null, isYtOverlay: true, sourceEl: el });

    console.log("[AdHighlighter] YouTube: created overlay", {
      top: Math.round(rect.top + window.scrollY),
      width: Math.round(rect.width),
      height: Math.round(rect.height),
    });
  }

  function detectYouTubeAds(_found) {
    // Helper: find the ad card container for an element
    function ytFindAdContainer(el) {
      const container = el.closest(
        "ytd-promoted-video-renderer, ytd-video-renderer, ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer",
      );
      if (container) return container;
      return walkUpTo(el, (ancestor) => {
        return ancestor.getBoundingClientRect().width > 400;
      }, 15);
    }

    // Collect all ad elements, then create overlays
    const adElements = new Set();

    // 1. Known ad custom elements
    const adSelectors = [
      "ytd-ad-slot-renderer",
      "ytd-promoted-sparkles-web-renderer",
      "ytd-display-ad-renderer",
      "ytd-promoted-video-renderer",
      "ytd-in-feed-ad-layout-renderer",
    ];
    for (const sel of adSelectors) {
      document.querySelectorAll(sel).forEach((el) => {
        console.log("[AdHighlighter] YouTube: found " + sel);
        adElements.add(el);
      });
    }

    // 2. Ad-related custom elements and classes
    document
      .querySelectorAll("ad-button-hover-overlay-view-model, [class*='ytwAd']")
      .forEach((el) => {
        console.log("[AdHighlighter] YouTube: found ad element", el.tagName, (typeof el.className === "string" ? el.className : "").substring(0, 80));
        const container = ytFindAdContainer(el);
        adElements.add(container || el);
      });

    // 3. TreeWalker: find "Sponsored" text nodes
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let textNode;
    while ((textNode = walker.nextNode())) {
      const text = textNode.textContent.trim();
      if (text !== "Sponsored" && !/^Sponsored\s*[·•\u00B7\u2022\u2027]/.test(text)) continue;

      const parentEl = textNode.parentElement;
      if (!parentEl) continue;

      console.log("[AdHighlighter] YouTube: found 'Sponsored' text", {
        text: text.substring(0, 60),
        parentTag: parentEl.tagName,
      });

      const container = ytFindAdContainer(parentEl);
      if (container) adElements.add(container);
    }

    // 4. Video player ads
    const adModule = document.querySelector(".ytp-ad-module");
    if (adModule && adModule.children.length > 0) {
      console.log("[AdHighlighter] YouTube: video ad module active");
      adElements.add(adModule);
    }
    const adShowing = document.querySelector(".ad-showing");
    if (adShowing) {
      console.log("[AdHighlighter] YouTube: player in ad-showing state");
      adElements.add(adShowing);
    }

    // Deduplicate and create overlays (not CSS highlights)
    const unique = [...adElements].filter((el) => {
      return ![...adElements].some((other) => other !== el && other.contains(el));
    });

    for (const el of unique) {
      ytCreateOverlay(el);
    }
  }

  // ---- Facebook: detect ads with strict validation ----
  const fbHighlighted = new WeakSet();

  function detectFacebookAds(found) {
    // Walk up from signal element to find post container.
    // Stop at offsetHeight > 500 but never grab feed/main.
    function fbFindContainer(el) {
      let current = el;
      for (let i = 0; i < 15; i++) {
        current = current.parentElement;
        if (!current || current === document.body) break;

        // Never highlight the feed or main container
        const role = current.getAttribute("role");
        if (role === "feed" || role === "main") break;

        if (current.offsetHeight > 500) {
          return current;
        }
      }
      return null;
    }

    // Validate: container must have at least one strong ad signal
    function isConfirmedAd(container) {
      if (container.querySelector('a[href*="/ads/about"]')) return true;
      if (container.querySelector('[data-ad-rendering-role^="cta"]')) return true;
      if (container.querySelector('a[aria-label*="Sponsored"]')) return true;
      return false;
    }

    // Check if container (or any ancestor/descendant) is already tracked
    function isAlreadyHighlighted(container) {
      if (fbHighlighted.has(container)) return true;
      let parent = container.parentElement;
      while (parent && parent !== document.body) {
        if (fbHighlighted.has(parent)) return true;
        parent = parent.parentElement;
      }
      if (container.querySelector(".adh-v2-highlighted")) return true;
      return false;
    }

    function addContainer(container, signal) {
      if (!container || isAlreadyHighlighted(container)) return;
      if (!isConfirmedAd(container)) return;
      fbHighlighted.add(container);
      console.log("[AdHighlighter] Facebook:", signal, "container:", container.offsetWidth, "x", container.offsetHeight);
      found.add(container);
    }

    // Primary: /ads/about links (hidden but present in DOM)
    document.querySelectorAll('a[href*="/ads/about"]').forEach((link) => {
      const container = fbFindContainer(link);
      addContainer(container, "found /ads/about link");
    });

    // Secondary: aria-label="Sponsored" links
    document.querySelectorAll('a[aria-label*="Sponsored"]').forEach((link) => {
      const container = fbFindContainer(link);
      addContainer(container, "found aria-label Sponsored link");
    });

    // Tertiary: data-ad-comet-preview WITH strict CTA validation
    document.querySelectorAll("[data-ad-comet-preview]").forEach((el) => {
      const container = fbFindContainer(el);
      if (container && container.querySelector('[data-ad-rendering-role^="cta"]')) {
        addContainer(container, "found data-ad-comet-preview with CTA");
      }
    });
  }

  // ---- Instagram: find "Ad" spans, walk up to <article>, highlight ----
  function detectInstagramAds(found) {
    const spans = document.querySelectorAll("span");

    for (const span of spans) {
      const text = span.textContent.trim();
      if (text !== "Ad" || text.length !== 2) continue;

      // Dedup: check if a badge already exists nearby
      const next = span.nextElementSibling;
      const parentNext = span.parentElement?.nextElementSibling;
      if ((next && next.textContent.includes("\u26A0")) || (parentNext && parentNext.textContent.includes("\u26A0"))) continue;

      const article = span.closest("article");
      console.log("[AdHighlighter] Instagram: found Ad span", span, "article:", article);

      if (article) {
        if (!article.classList.contains("adh-v2-highlighted")) {
          found.add(article);
        }
      } else {
        span.style.cssText += "color: #ff2d2d !important; font-weight: 700 !important;";

        const badge = document.createElement("span");
        badge.textContent = " \u26A0 AD";
        badge.style.cssText = "background:#ff2d2d;color:white;font-size:11px;font-weight:700;padding:2px 6px;border-radius:3px;margin-left:6px;z-index:9999;";
        span.insertAdjacentElement("afterend", badge);
      }
    }
  }

  function detectAmazonAds(found) {
    // Sponsored result containers (data attribute)
    document
      .querySelectorAll('[data-component-type="sp-sponsored-result"]')
      .forEach((el) => {
        console.log("[AdHighlighter] Amazon: found sp-sponsored-result", {
          class: el.className,
        });
        found.add(el);
      });

    // Sponsored labels with Amazon-specific classes
    for (const sel of [
      "span.puis-label-popover-default",
      "span.s-label-popover-default",
    ]) {
      document.querySelectorAll(sel).forEach((span) => {
        if (span.textContent.trim().toLowerCase() === "sponsored") {
          const container = findAdContainer(span);
          if (container) {
            console.log("[AdHighlighter] Amazon: 'Sponsored' label (" + sel + ")", {
              containerTag: container.tagName,
            });
            found.add(container);
          }
        }
      });
    }

    // Fallback: search result items containing a "Sponsored" span
    document.querySelectorAll(".s-result-item").forEach((item) => {
      for (const span of item.querySelectorAll("span")) {
        if (span.textContent.trim().toLowerCase() === "sponsored") {
          console.log("[AdHighlighter] Amazon: sponsored result item", {
            asin: item.getAttribute("data-asin"),
          });
          found.add(item);
          break;
        }
      }
    });
  }

  // ---- LinkedIn: inline overlay approach ----
  // Uses position:relative on container + position:absolute inset:0 child
  // with outline (not border) so it doesn't shift layout.

  function linkedinCreateOverlay(container, label) {
    if (container.getAttribute("data-ad-highlighted")) return;
    if (container.offsetWidth === 0 || container.offsetHeight === 0) return;

    container.setAttribute("data-ad-highlighted", "true");

    // Make container the positioning anchor
    const pos = getComputedStyle(container).position;
    if (pos === "static") {
      container.style.position = "relative";
    }

    const overlay = document.createElement("div");
    overlay.className = "adh-v2-linkedin-overlay";
    overlay.style.cssText = [
      "position: absolute",
      "inset: 0",
      "outline: 3px solid #ff2d2d",
      "outline-offset: -3px",
      "background: rgba(255, 45, 45, 0.06)",
      "pointer-events: none",
      "z-index: 999",
      "border-radius: 8px",
      "box-sizing: border-box",
    ].join(" !important;") + " !important";

    const badge = document.createElement("div");
    badge.textContent = "\u26A0 AD DETECTED";
    badge.style.cssText = [
      "position: absolute",
      "top: 4px",
      "left: 4px",
      "background: #ff2d2d",
      "color: white",
      "font-size: 11px",
      "font-weight: 700",
      "padding: 3px 8px",
      "border-radius: 4px",
      "pointer-events: none",
      "font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      "letter-spacing: 0.3px",
      "line-height: 14px",
    ].join(" !important;") + " !important";
    overlay.appendChild(badge);

    const btn = document.createElement("button");
    btn.className = "adh-v2-dismiss-btn";
    btn.textContent = "\u2715 Not an ad";
    btn.title = "Dismiss \u2014 this is not an ad";
    btn.style.cssText = "pointer-events: auto !important;";
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      dismissElement(overlay);
    });
    overlay.appendChild(btn);

    container.appendChild(overlay);
    highlightedElements.set(overlay, { btn, isLinkedInOverlay: true, sourceEl: container });

    console.log("[AdHighlighter] LinkedIn: highlighted " + label, {
      tag: container.tagName,
      w: container.offsetWidth,
      h: container.offsetHeight,
    });
  }

  function detectLinkedInAds(_found) {
    if (!isContextValid()) return;

    // --- Feed: "Promoted" text via TreeWalker (restored from working version) ---
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      null,
    );

    let textNode;
    while ((textNode = walker.nextNode())) {
      const trimmedText = textNode.textContent.trim();
      if (!trimmedText.toLowerCase().startsWith("promoted") || trimmedText.length >= 60) continue;

      const parentEl = textNode.parentElement;
      if (!parentEl) continue;

      console.log("[AdHighlighter] LinkedIn: found 'Promoted' text node in <" + parentEl.tagName.toLowerCase() + ">", {
        class: parentEl.className,
        parentTag: parentEl.parentElement?.tagName,
        parentClass: parentEl.parentElement?.className,
      });

      // Walk up to feed post container using walkUpTo (the approach that was working)
      const post = walkUpTo(parentEl, (el) => {
        if (el.getAttribute("data-urn") !== null) return true;
        if (el.getAttribute("data-id") !== null && el.tagName === "DIV")
          return true;
        const cls = (
          typeof el.className === "string" ? el.className : ""
        ).toLowerCase();
        if (cls.includes("feed-shared-update")) return true;
        if (cls.includes("occludable-update")) return true;
        return false;
      }, 20);

      if (post) {
        console.log("[AdHighlighter] LinkedIn: promoted post container", {
          tag: post.tagName,
          class: post.className,
          dataUrn: post.getAttribute("data-urn"),
          dataId: post.getAttribute("data-id"),
        });
        linkedinCreateOverlay(post, "feed ad");
      } else {
        // Fallback: find a reasonable ancestor that looks like a card
        const card = walkUpTo(parentEl, (el) => {
          if (el.querySelector('input, textarea, [contenteditable="true"]'))
            return false;
          if (el.tagName !== "DIV" && el.tagName !== "SECTION") return false;
          const rect = el.getBoundingClientRect();
          return rect.height > 100 && el.children.length >= 2 && el.children.length <= 30;
        }, 15);

        if (card) {
          console.log("[AdHighlighter] LinkedIn: promoted card (fallback)", {
            tag: card.tagName,
            class: card.className,
          });
          linkedinCreateOverlay(card, "feed ad");
        } else {
          console.log("[AdHighlighter] LinkedIn: 'Promoted' found but no suitable container");
        }
      }
    }

    // --- Sidebar: promoted company cards (NEW) ---
    // Signal 1: data-testid="promoted-badge"
    document.querySelectorAll('[data-testid="promoted-badge"]').forEach((badge) => {
      const container = badge.closest('[data-testid="follow-company-container"]') ||
                        badge.closest("#ads-container") ||
                        badge.closest("aside");
      if (container && !container.getAttribute("data-ad-highlighted")) {
        linkedinCreateOverlay(container, "sidebar ad");
      }
    });

    // Signal 2: direct container selectors
    document.querySelectorAll('#ads-container, [data-testid="follow-company-container"]').forEach((el) => {
      if (!el.getAttribute("data-ad-highlighted")) {
        linkedinCreateOverlay(el, "sidebar ad");
      }
    });
  }

  // ---- Twitter/X: overlay approach ----
  // Twitter's stacking contexts hide CSS-based highlights behind cards.
  // We create position:absolute overlays on document.body instead.

  function twitterCreateOverlay(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    const top = Math.round(rect.top + window.scrollY);
    const left = Math.round(rect.left + window.scrollX);

    // Dedup: skip if an overlay already exists within 50px of this position
    for (const [, data] of highlightedElements) {
      if (data.isTwitterOverlay && Math.abs(data.overlayTop - top) < 50 && Math.abs(data.overlayLeft - left) < 50) {
        return;
      }
    }

    const overlay = document.createElement("div");
    overlay.className = "adh-v2-twitter-overlay";
    overlay.style.cssText = [
      "position: absolute",
      "top: " + top + "px",
      "left: " + left + "px",
      "width: " + Math.round(rect.width) + "px",
      "height: " + Math.round(rect.height) + "px",
      "border: 4px solid #ff2d2d",
      "background: rgba(255, 45, 45, 0.08)",
      "pointer-events: none",
      "z-index: 2147483647",
      "border-radius: 12px",
      "box-sizing: border-box",
    ].join(" !important;") + " !important";

    const badge = document.createElement("div");
    badge.textContent = "\u26A0 AD DETECTED";
    badge.style.cssText = [
      "position: absolute",
      "bottom: -28px",
      "left: 0",
      "background: #ff2d2d",
      "color: white",
      "font-size: 12px",
      "font-weight: 700",
      "padding: 4px 10px",
      "border-radius: 4px",
      "pointer-events: none",
      "font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      "letter-spacing: 0.3px",
      "line-height: 16px",
    ].join(" !important;") + " !important";
    overlay.appendChild(badge);

    const btn = document.createElement("button");
    btn.className = "adh-v2-dismiss-btn";
    btn.textContent = "\u2715 Not an ad";
    btn.title = "Dismiss \u2014 this is not an ad";
    btn.style.cssText = "pointer-events: auto !important;";
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      dismissElement(overlay);
    });
    overlay.appendChild(btn);

    document.body.appendChild(overlay);
    highlightedElements.set(overlay, { btn, isTwitterOverlay: true, sourceEl: el, overlayTop: top, overlayLeft: left });

    console.log("[AdHighlighter] Twitter: created overlay", {
      top,
      width: Math.round(rect.width),
      height: Math.round(rect.height),
    });
  }

  function detectTwitterAds(_found) {
    // Walk up to Twitter's tweet container
    function findTweetContainer(el) {
      return walkUpTo(el, (ancestor) => {
        const testId = ancestor.getAttribute("data-testid");
        return testId === "tweet" || testId === "tweetText";
      }, 15);
    }

    const adElements = new Set();

    // Signal 1: "Ad" text spans (exact case — Twitter uses capital A)
    document.querySelectorAll("span").forEach((span) => {
      if (span.textContent.trim() === "Ad") {
        const container = findTweetContainer(span);
        if (container) adElements.add(container);
      }
    });

    // Signal 2: /i/ads links
    document.querySelectorAll('a[href*="/i/ads"]').forEach((link) => {
      const container = findTweetContainer(link);
      if (container) adElements.add(container);
    });

    // Signal 3: promotedIndicator data-testid
    document.querySelectorAll('[data-testid="promotedIndicator"]').forEach((el) => {
      const container = findTweetContainer(el);
      if (container) adElements.add(container);
    });

    // Deduplicate and create overlays (not CSS highlights)
    const unique = [...adElements].filter((el) => {
      return ![...adElements].some((other) => other !== el && other.contains(el));
    });

    for (const el of unique) {
      twitterCreateOverlay(el);
    }
  }

  function detectRedditAds(found) {
    // shreddit-ad-post custom elements
    document.querySelectorAll("shreddit-ad-post").forEach((el) => {
      console.log("[AdHighlighter] Reddit: found shreddit-ad-post");
      found.add(el);
    });

    // Posts with "promoted" flair
    document.querySelectorAll("span").forEach((span) => {
      if (span.textContent.trim().toLowerCase() === "promoted") {
        const container = findAdContainer(span);
        if (container) {
          console.log("[AdHighlighter] Reddit: promoted post", {
            containerTag: container.tagName,
            containerClass: container.className,
          });
          found.add(container);
        }
      }
    });
  }

  // Booking.com: no third-party ads — all content is first-party.
  // This detector exists solely to claim the domain so the generic fallback is skipped.
  function detectBookingAds(_found) {
    console.log("[AdHighlighter] Booking.com: skipping — no third-party ads");
  }

  // ---- Always-on: ad-serving iframes ----

  function detectAdIframes(found) {
    document.querySelectorAll("iframe").forEach((iframe) => {
      try {
        const src = (iframe.src || iframe.dataset?.src || "").toLowerCase();
        if (AD_IFRAME_DOMAINS.some((d) => src.includes(d))) {
          const container = findAdContainer(iframe);
          console.log("[AdHighlighter] Ad iframe detected:", {
            src: src.slice(0, 100),
            container: container
              ? { tag: container.tagName, class: container.className }
              : null,
          });
          found.add(container || iframe);
        }
      } catch (e) {
        // Cross-origin iframes may throw
      }
    });
  }

  // ---- Generic fallback: Island analysis ----

  function detectByIslandAnalysis(found) {
    const viewportArea = window.innerWidth * window.innerHeight;
    if (viewportArea === 0) return;

    const candidates = document.querySelectorAll(
      "div, article, section, aside, ins",
    );
    let checked = 0;

    for (const el of candidates) {
      if (EXCLUDED_TAGS.has(el.tagName)) continue;

      // Skip footer elements and anything nested inside a <footer>
      if (el.tagName === "FOOTER" || el.closest("footer")) continue;

      // Quick size filter: between 5% and 35% of viewport
      const rect = el.getBoundingClientRect();
      const area = rect.width * rect.height;
      if (area < viewportArea * 0.05 || area > viewportArea * 0.35) continue;
      if (rect.width < 100 || rect.height < 50) continue;

      checked++;
      if (checked > 200) break; // Safety limit

      let score = 0;
      const reasons = [];

      // (1) External links — 3 points if >70% go to a different domain
      const links = el.querySelectorAll("a[href]");
      if (links.length > 0) {
        let externalCount = 0;
        for (const a of links) {
          try {
            const url = new URL(a.href);
            if (url.hostname !== domain) externalCount++;
          } catch {}
        }
        if (externalCount / links.length > 0.7) {
          score += 3;
          reasons.push(`external links ${externalCount}/${links.length}`);
        }
      }

      // (2) Visual distinction — 2 points if different bg, border, or shadow
      const style = window.getComputedStyle(el);
      const parentEl = el.parentElement;
      if (parentEl) {
        const parentStyle = window.getComputedStyle(parentEl);
        const hasBorder =
          style.borderStyle !== "none" && parseFloat(style.borderWidth) > 0;
        const hasShadow = style.boxShadow !== "none";
        const differentBg =
          style.backgroundColor !== parentStyle.backgroundColor &&
          style.backgroundColor !== "rgba(0, 0, 0, 0)" &&
          style.backgroundColor !== "transparent";
        if (hasBorder || hasShadow || differentBg) {
          score += 2;
          reasons.push("visually distinct");
        }
      }

      // (3) Soft keyword — 1 point
      const textContent = el.textContent.toLowerCase();
      if (SOFT_KEYWORDS.some((kw) => textContent.includes(kw))) {
        score += 1;
        reasons.push("soft keyword");
      }

      // Skip elements containing security/safety messaging (not ads)
      if (
        textContent.includes("stay safe") ||
        textContent.includes("protect your security") ||
        textContent.includes("privacy notice")
      ) {
        continue;
      }

      // (4) Iframe present — 2 points
      if (el.querySelector("iframe")) {
        score += 2;
        reasons.push("has iframe");
      }

      // (5) Tracking params in image URLs — 1 point
      const trackingParams = [
        "utm_",
        "click_id",
        "tracking",
        "impression",
        "ad_id",
        "campaign_id",
      ];
      const hasTracking = [...el.querySelectorAll("img")].some((img) =>
        trackingParams.some((p) => (img.src || "").includes(p)),
      );
      if (hasTracking) {
        score += 1;
        reasons.push("tracking params");
      }

      // (6) Ad-related class/ID pattern — 3 points
      if (elementMatchesAnyAdPattern(el)) {
        score += 3;
        reasons.push("ad class/id pattern");
      }

      if (score >= 6) {
        console.log(`[AdHighlighter] Island detected (score ${score}):`, {
          tag: el.tagName,
          class: el.className,
          id: el.id,
          size: `${Math.round(rect.width)}x${Math.round(rect.height)}`,
          reasons,
        });
        found.add(el);
      }
    }

    console.log(
      "[AdHighlighter] Island analysis: checked",
      checked,
      "candidates",
    );
  }

  // ----------------------------------------------------------
  // 4. CONTAINER FINDING
  // ----------------------------------------------------------

  function findAdContainer(startElement) {
    if (!startElement) return null;

    let el = startElement;
    let best = startElement;
    const viewportArea = window.innerWidth * window.innerHeight;

    console.log("[AdHighlighter] findAdContainer start:", {
      tag: startElement.tagName,
      class: startElement.className,
      text: startElement.textContent?.slice(0, 80),
    });

    for (let i = 0; i < 15; i++) {
      const parent = el.parentElement;
      if (!parent || EXCLUDED_TAGS.has(parent.tagName)) {
        console.log(
          `[AdHighlighter]   step ${i}: STOP — ${!parent ? "no parent" : "excluded tag " + parent.tagName}`,
        );
        break;
      }

      const parentRect = parent.getBoundingClientRect();
      const parentArea = parentRect.width * parentRect.height;

      if (parentArea > viewportArea * 0.4) {
        console.log(
          `[AdHighlighter]   step ${i}: STOP — parent too large (${Math.round((parentArea / viewportArea) * 100)}% of viewport)`,
          { tag: parent.tagName, class: parent.className },
        );
        break;
      }

      if (parent.children.length > 20) {
        console.log(
          `[AdHighlighter]   step ${i}: STOP — too many children (${parent.children.length})`,
          { tag: parent.tagName, class: parent.className },
        );
        break;
      }

      if (CONTAINER_TAGS.has(parent.tagName)) {
        console.log(
          `[AdHighlighter]   step ${i}: container boundary, updating best`,
          { tag: parent.tagName, class: parent.className },
        );
        best = parent;
        el = parent;
        continue;
      }

      if (elementMatchesAnyAdPattern(parent)) {
        console.log(
          `[AdHighlighter]   step ${i}: MATCH — ad-related class/id`,
          { tag: parent.tagName, class: parent.className, id: parent.id },
        );
        return parent;
      }

      console.log(`[AdHighlighter]   step ${i}: walking up`, {
        tag: parent.tagName,
        class: parent.className,
      });
      best = parent;
      el = parent;
    }

    console.log("[AdHighlighter]   => returning best:", {
      tag: best.tagName,
      class: best.className,
      id: best.id,
    });
    return best;
  }

  // Walk up the DOM from startEl until predicate(el) returns true
  function walkUpTo(startEl, predicate, maxSteps = 15) {
    let el = startEl;
    for (let i = 0; i < maxSteps; i++) {
      el = el.parentElement;
      if (!el || EXCLUDED_TAGS.has(el.tagName)) return null;
      if (predicate(el)) return el;
    }
    return null;
  }

  // ----------------------------------------------------------
  // 5. HIGHLIGHTING & UI
  // ----------------------------------------------------------

  function highlightElement(el) {
    el.classList.add("adh-v2-highlighted");

    const btn = document.createElement("button");
    btn.className = "adh-v2-dismiss-btn";
    btn.textContent = "\u2715 Not an ad";
    btn.title = "Dismiss \u2014 this is not an ad";
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      dismissElement(el);
    });

    const position = window.getComputedStyle(el).position;
    if (position === "static") {
      el.style.position = "relative";
    }

    el.appendChild(btn);
    highlightedElements.set(el, { btn });
  }

  function dismissElement(el) {
    const data = highlightedElements.get(el);
    if (data && (data.isYtOverlay || data.isTwitterOverlay || data.isLinkedInOverlay)) {
      // For LinkedIn inline overlays, clean up the container's data attribute
      if (data.isLinkedInOverlay && data.sourceEl) {
        data.sourceEl.removeAttribute("data-ad-highlighted");
      }
      el.remove();
      highlightedElements.delete(el);
      updateBadge();
      return;
    }
    el.classList.remove("adh-v2-highlighted");
    if (data && data.btn && data.btn.parentElement) {
      data.btn.remove();
    }
    highlightedElements.delete(el);

    const selector = generateSelector(el);
    if (selector) {
      dismissedSelectors.add(selector);
      chrome.storage.local.set({
        [`dismissed_${domain}`]: Array.from(dismissedSelectors),
      });
    }

    updateBadge();
  }

  function isDismissed(el) {
    const selector = generateSelector(el);
    return selector && dismissedSelectors.has(selector);
  }

  function generateSelector(el) {
    if (el.id) return `#${CSS.escape(el.id)}`;

    const parts = [];
    let current = el;
    for (let i = 0; i < 3; i++) {
      if (!current || current === document.body) break;
      let part = current.tagName.toLowerCase();
      if (current.id) {
        part = `#${CSS.escape(current.id)}`;
        parts.unshift(part);
        break;
      }
      if (current.className && typeof current.className === "string") {
        const cls = current.className
          .trim()
          .split(/\s+/)
          .slice(0, 2)
          .map((c) => `.${CSS.escape(c)}`)
          .join("");
        part += cls;
      }
      parts.unshift(part);
      current = current.parentElement;
    }
    return parts.join(" > ") || null;
  }

  function clearAllHighlights() {
    highlightedElements.forEach((data, el) => {
      if (data.isYtOverlay || data.isTwitterOverlay || data.isLinkedInOverlay) {
        if (data.isLinkedInOverlay && data.sourceEl) {
          data.sourceEl.removeAttribute("data-ad-highlighted");
        }
        el.remove();
      } else {
        el.classList.remove("adh-v2-highlighted");
        if (data.btn && data.btn.parentElement) {
          data.btn.remove();
        }
      }
    });
    highlightedElements.clear();
    updateBadge();
  }

  function updateBadge() {
    try {
      chrome.runtime.sendMessage({
        type: "updateBadge",
        count: highlightedElements.size,
      });
    } catch (e) {
      // Extension context may be invalidated
    }
  }

  // ----------------------------------------------------------
  // 6. MUTATION OBSERVER (catch dynamically loaded ads)
  // ----------------------------------------------------------

  const isFacebook = /(?:^|\.)facebook\.com$/.test(domain);

  const observer = new MutationObserver((mutations) => {
    if (!enabled || !isContextValid()) return;

    let shouldRescan = false;
    for (const mutation of mutations) {
      if (mutation.addedNodes.length > 0) {
        shouldRescan = true;
        break;
      }
    }

    if (shouldRescan) {
      if (isFacebook) {
        // Throttle: run at most once per 500ms (not debounce)
        const now = Date.now();
        if (now - (observer._lastFbScan || 0) >= 500) {
          observer._lastFbScan = now;
          scanPage();
        } else if (!observer._fbThrottleTimeout) {
          observer._fbThrottleTimeout = setTimeout(() => {
            observer._lastFbScan = Date.now();
            observer._fbThrottleTimeout = null;
            scanPage();
          }, 500 - (now - (observer._lastFbScan || 0)));
        }
      } else {
        clearTimeout(observer._timeout);
        const isInstagram = /(?:^|\.)instagram\.com$/.test(domain);
        const throttle = isInstagram ? 1000 : 500;
        observer._timeout = setTimeout(() => scanPage(), throttle);
      }
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });

  // LinkedIn: rescan on scroll to catch lazy-loaded feed posts
  if (/(?:^|\.)linkedin\.com$/.test(domain)) {
    let lastScrollScan = 0;
    window.addEventListener("scroll", () => {
      if (!isContextValid()) return;
      if (Date.now() - lastScrollScan > 500) {
        lastScrollScan = Date.now();
        scanPage();
      }
    });
  }

  // Facebook: scroll rescan + timed initial rescans for progressive feed loading
  if (isFacebook) {
    let lastScrollScan = 0;
    window.addEventListener("scroll", () => {
      if (!isContextValid()) return;
      if (Date.now() - lastScrollScan > 1000) {
        lastScrollScan = Date.now();
        scanPage();
      }
    });
    // Immediate + timed rescans to catch initial batch of ads
    scanPage();
    setTimeout(() => scanPage(), 500);
    setTimeout(() => scanPage(), 1500);
    setTimeout(() => scanPage(), 3000);
  }

  // Instagram: rescan on scroll — DOM elements are recycled on scroll
  if (/(?:^|\.)instagram\.com$/.test(domain)) {
    let lastScrollScan = 0;
    window.addEventListener("scroll", () => {
      if (!isContextValid()) return;
      if (Date.now() - lastScrollScan > 1500) {
        lastScrollScan = Date.now();
        scanPage();
      }
    });
  }

  // Twitter/X: rescan on scroll — DOM elements are replaced on scroll
  if (/(?:^|\.)twitter\.com$/.test(domain) || /(?:^|\.)x\.com$/.test(domain)) {
    let lastScrollScan = 0;
    window.addEventListener("scroll", () => {
      if (!isContextValid()) return;
      if (Date.now() - lastScrollScan > 1500) {
        lastScrollScan = Date.now();
        scanPage();
      }
    });
  }

  // ----------------------------------------------------------
  // UTILITY
  // ----------------------------------------------------------

  function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function containsAdSegment(str, pattern) {
    const regex = new RegExp(
      `(^|[\\s\\-_])${escapeRegex(pattern)}([\\s\\-_]|$)`,
      "i",
    );
    return regex.test(str);
  }

  function elementMatchesAnyAdPattern(el) {
    const classes = (
      typeof el.className === "string" ? el.className : ""
    ).toLowerCase();
    const id = (el.id || "").toLowerCase();
    return AD_CLASS_PATTERNS.some(
      (p) => containsAdSegment(classes, p) || (id && containsAdSegment(id, p)),
    );
  }
})();
